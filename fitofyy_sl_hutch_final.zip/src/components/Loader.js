import React from 'react'

const Loader = () => {
  return (
    <div>
        <div className="App">
      <header className="App-header">
        <p className="smoky" data-text="Loading...">Loading...</p>
      </header>
    </div>
    </div>
  )
}

export default Loader
